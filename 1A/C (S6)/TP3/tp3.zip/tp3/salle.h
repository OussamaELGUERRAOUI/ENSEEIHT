#ifndef SALLE__H
#define SALLE__H

#include "date.h"

struct salle {
	char *nom;
	char *batiment;
};
typedef struct salle salle;
#endif
