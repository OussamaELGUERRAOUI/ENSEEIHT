#include "cours.h"


void initialiser_cours(cours *c, salle s, enseignant e){
}
