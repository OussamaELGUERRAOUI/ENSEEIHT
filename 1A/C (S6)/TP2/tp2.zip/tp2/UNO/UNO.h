#ifndef UNO__H
#define UNO__H
#include "jeu.h"

int preparer_jeu_UNO(jeu le_jeu, int N, t_main* main_A, t_main* main_B, carte* last);


void test_preparer_jeu_UNO();

#endif
