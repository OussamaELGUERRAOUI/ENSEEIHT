
#include <assert.h>
#include <stdlib.h>
#include <stdio.h>

// Consignes pour une obtenir une exécution sans erreur : 
//     - compléter les instruction **** TODO **** 
// Attention : toutes les variables sont ici allouées et libérées dynamiquent

int main(){

    int* ptr_int; //un entier en mémoire dynamique 
    // **** TODO ****
    // Allocation et initialisation à la valeur 100;


    assert(*ptr_int == 100);

        
    //**** TODO **** 
    //Libérer toute la mémoire dynamique
    
    assert(!ptr_int);

    printf("%s", "Bravo ! Tous les tests passent.\n");
    return EXIT_SUCCESS;
}
